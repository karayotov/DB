﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst
{
    public class DbConfiguration
    {
        public const string ConnectionString = @"Server=DESKTOP-UHHNPGM\SQLEXPRESS;Database=SoftUni;Integrated Security=True";
    }
}
