﻿namespace P02_DatabaseFirst
{
    class Startup
    {
        static void Main(string[] args)
        {
           
        }
    }
}
